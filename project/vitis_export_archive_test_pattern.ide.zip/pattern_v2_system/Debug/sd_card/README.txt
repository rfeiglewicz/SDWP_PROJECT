-= SD card boot image =-

Platform: design_1_wrapper
Application: design_1_wrapper_hdmi_75Mhz_v1

1. Copy the contents of this directory to an SD card
2. Set boot mode to SD
3. Insert SD card and turn board on
